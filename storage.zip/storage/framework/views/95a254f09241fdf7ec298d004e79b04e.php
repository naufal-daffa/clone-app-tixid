<?php $__env->startSection('content'); ?>
    <div class="container pt-5">
        <div class="d-flex justify-content-center">
            <div>
                <div class="w-75 d-block m-auto">
                    <div style="width: 150px; height: 200px;">
                        <img src="https://nos.jkt-1.neo.id/media.cinema21.co.id/movie-images/15MPOF.jpg"
                            alt="" class="w-100">
                    </div>
                </div>
            </div>

            <div class="ms-5 mt-4 ">
                <h5></h5>
                <table>
                    <tr>
                        <td><b class="text-secondary">Genre</b></td>
                        <td class="px-3"></td>
                        <td>Horror, Romance</td>
                    </tr>
                    <tr>
                        <td><b class="text-secondary">Durasi</b></td>
                        <td class="px-3"></td>
                        <td>1 Jam 59 Menit</td>
                    </tr>
                    <tr>
                        <td><b class="text-secondary">Sutradara</b></td>
                        <td class="px-3"></td>
                        <td>Endiartod</td>
                    </tr>
                    <tr>
                        <td><b class="text-secondary">Rating Usia</b></td>
                        <td class="px-3"></td>
                        <td><span class="badge badge-danger">18+</span></td>
                    </tr>
                    <tr>
                        <td><b class="text-secondary">Deskripsi</b></td>
                        <td class="px-3"></td>
                        <td style="max-width: 500px;">"Mengisahkan tentang sekelompok delapan anak yang membentuk "Tim Merah Putih" di sebuah desa. Mereka ditugaskan untuk menjaga Bendera Pusaka yang akan dikibarkan dalam upacara Hari Kemerdekaan Indonesia pada 17 Agustus"</td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="w-100 row mt-5">
            <div class="col-6 pe-5">
                <div class="d-flex flex-column justify-content-end align-items-end">
                    <div class="d-flex align-items-center">
                        <h3 class="text-warning me-1">0.2</h3>
                        <i class="fa fa-star text-muted"></i>
                        <i class="fa fa-star text-muted"></i>
                        <i class="fa fa-star text-muted"></i>
                    </div>
                    <small>3.894 Vote</small>
                </div>
            </div>
            <div class="col-6 ps-5" style="border-left: 2px solid #c7c7c7">
                <div class="d-flex align-items-center">
                    <div class="fa fa-heart text-danger me-2"></div>
                    <b>Masukan Watchlist</b>
                </div>
                <small>0 Orang</small>
            </div>
            <div class="d-flex w-100 bg-light mt-3">
                <div class="dropdown">
                    <button class="btn btn-light dropdown-toggle d-flex align-items-center w-100" type="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Bioskop
                    </button>
                    <ul class="dropdown-menu w-100">
                        <li><a class="dropdown-item " href="#">Bogor</a></li>
                        <li><a class="dropdown-item " href="#">Jakarta</a></li>
                        <li><a class="dropdown-item " href="#">Bandung</a></li>
                    </ul>
                </div>
                <div class="dropdown">
                    <button class="btn btn-light dropdown-toggle d-flex align-items-center w-100" type="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Sortir
                    </button>
                    <ul class="dropdown-menu w-100">
                        <li><a class="dropdown-item " href="#">Harga</a></li>
                        <li><a class="dropdown-item " href="#">Alfabet</a></li>
                    </ul>
                </div>
            </div>
            <div class="mb-5">
                <div class="w-100 my-3">
                    <i class="fa-solid fa-building"></i><b class="ms-2">Lippo Plaza Ekalokasari</b>
                    <br>
                    <small class="ms-3">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Sed soluta et eligendi aut perferendis cumque illum beatae quod, nobis odit!</small>
                    <div class="d-flex gap-3 ps-3 my-2">
                        <div class="btn btn-outline-secondary">15.00</div>
                        <div class="btn btn-outline-secondary">16.30</div>
                        <div class="btn btn-outline-secondary">18.00</div>
                        <div class="btn btn-outline-secondary">20.00</div>
                        <div class="btn btn-outline-secondary">20.30</div>
                    </div>
                </div>
                <hr>
                <div class="w-100 my-3">
                    <i class="fa-solid fa-building"></i><b class="ms-2">Ramayana Tajur</b>
                    <br>
                    <small class="ms-3">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eius, commodi aliquam? Possimus exercitationem temporibus suscipit!</small>
                    <div class="d-flex gap-3 ps-3 my-2">
                        <div class="btn btn-outline-secondary">15.00</div>
                        <div class="btn btn-outline-secondary">16.30</div>
                        <div class="btn btn-outline-secondary">18.00</div>
                        <div class="btn btn-outline-secondary">20.00</div>
                        <div class="btn btn-outline-secondary">20.30</div>
                    </div>
                </div>
            </div>
            <div class="w-100 p-2 bg-light text-center fixed">
                <a href="#" class="btn btn-primary"><i class="fa-solid fa-ticket"></i> BELI TIKET</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tixid-2\resources\views\schedule\detail-film.blade.php ENDPATH**/ ?>
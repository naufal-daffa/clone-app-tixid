<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="d-flex justify-content-end">
            <a href="<?php echo e(route('admin.movies.create')); ?>" class="btn btn-success">Tambah Data</a>
        </div>
        <h5 class="mt-3">Data Film</h5>
        <table class="table table-bordered">
            <tr>
                <th>#</th>
                <th>Poster</th>
                <th>Judul Film</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
            <td>

            </td>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tixid-2\resources\views/admin/movies/index.blade.php ENDPATH**/ ?>
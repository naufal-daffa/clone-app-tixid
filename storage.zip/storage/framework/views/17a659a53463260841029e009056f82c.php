<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <?php if(Session::get('failed')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('failed')); ?></div>
        <?php endif; ?>
        <?php if(Session::get('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
        <?php endif; ?>
        <div class="d-flex justify-content-end mt-3">
            <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-success">Tambah Data</a>
        </div>
        <table class="table table-responsive table-bordered mt-3">
            <h4>Data Pengguna (Admin & Staff)</h4>
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Role</th>
                <th>Aksi</th>
            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->email); ?></td>
                    <?php if($item->role == 'admin'): ?>
                        <td>
                            <div class="badge text-bg-info"><?php echo e($item['role']); ?></div>
                        </td>
                    <?php else: ?>
                        <td>
                            <div class="badge text-bg-success"><?php echo e($item['role']); ?></div>
                        </td>
                    <?php endif; ?>
                    <td class="d-flex justify-content-center">
                        <a href="<?php echo e(route('admin.users.edit', $item->id)); ?>" class="btn btn-primary">Edit</a>
                        
                        <form action="<?php echo e(route('admin.users.delete', $item->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger ms-2">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                Data Masih Kosong
            </tr>
            <?php endif; ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\tixid-2\resources\views\admin\users\index.blade.php ENDPATH**/ ?>